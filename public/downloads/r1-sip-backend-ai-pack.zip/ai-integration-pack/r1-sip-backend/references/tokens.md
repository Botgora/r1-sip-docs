# Tokens

本集成涉及三类 Token。所有服务端密钥都只能保存在接入方后端。

## 设备管理平台 Access Token

用途：调用设备管理平台 Open API。

获取方式：接入方后端使用平台分配的 `app_id` 和 `app_secret` 调用 `/api/open/auth/token`。

缓存建议：

- 按 `expires_in` 缓存。
- 提前 1-5 分钟刷新。
- 获取失败时返回明确错误，不要让前端直接感知平台密钥。

## MQTT JWT Token

用途：Web 座席端连接 MQTT Broker。

获取方式：接入方后端调用 MQTT Token API，使用声网 HTTP Basic Auth。

后端需要配置：

```text
R1SIP_MQTT_TOKEN_URL=https://api.sd-rtn.com/api/v1/projects/{APP_ID}/rtm/token
R1SIP_MQTT_BASIC_AUTH=Basic xxxxxx
R1SIP_MQTT_WS_URL=wss://example-mqtt/ws
```

请求时常用参数：

```json
{
  "uid": "caller-user-id",
  "client_id": "your_app_id-caller-caller-user-id"
}
```

返回给前端：

- `mqtt_ws_url`
- `mqtt_client_id`
- `mqtt_username`
- `mqtt_token`
- 需要订阅和发布的 topic

## 声网 RTC Token

用途：设备和 Web 座席加入同一个 RTC 频道传输语音。

后端需要配置：

```text
R1SIP_AGORA_APP_ID=your_app_id
R1SIP_AGORA_APP_CERTIFICATE=your_app_certificate
```

生成参数：

- `channel`：本次呼叫频道。
- `uid`：加入频道的用户 ID。
- `role`：发布音频的角色。
- `expire_at`：过期时间。

设备侧 RTC Token 通常在 `calls/prepare` 阶段生成并放入 CALL 消息。座席侧 RTC Token 可以在收到 `ANSWERED` 后再请求后端生成。

