# 验收检查清单

## 配置检查

- 已配置设备管理平台 URL、`app_id`、`app_secret`。
- 已配置 MQTT Token API、MQTT WebSocket URL、HTTP Basic Auth。
- 已配置声网 App ID 和 App Certificate。
- 所有密钥都只在后端配置中出现，没有进入前端代码。

## 后端接口检查

- `GET /r1-sip/devices` 能返回当前账号设备列表。
- `POST /r1-sip/calls/prepare` 能占用设备并返回 MQTT/RTC 参数。
- 同一设备并发调用 `calls/prepare` 时，只有一个请求成功。
- `POST /r1-sip/calls/{call_uuid}/rtc-token` 能返回座席侧 RTC Token。
- `POST /r1-sip/calls/{call_uuid}/finish` 能释放设备占用。
- 超时任务能清理长期未释放的设备占用。

## 联调检查

- 设备已通过 APP 完成配网和账号绑定。
- 设备在设备管理平台可查询。
- 主叫手机蓝牙已连接设备。
- Web 前端能连接 MQTT 并订阅 `evt/call`。
- Web 前端能发布 CALL。
- 设备能上报 `CALLING`、`RINGING`、`ANSWERED`、`HANGUP` 或 `ERROR`。
- 对端接听后，Web 座席能加入同一 RTC 频道并听到音频。

## 日志检查

- 外部 API 调用失败有清晰日志。
- Token 获取失败不打印密钥。
- 呼叫失败能记录 `call_uuid`、`device_id`、状态和原因码。
- 设备占用释放路径可追踪。

