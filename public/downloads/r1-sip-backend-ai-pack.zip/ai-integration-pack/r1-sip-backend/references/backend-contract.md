# 后端接口契约

以下接口是推荐给 Web 座席前端使用的接入方后端接口。实际路径可按项目风格调整。

## 查询设备列表

```http
GET /r1-sip/devices
```

请求上下文应包含当前登录用户。后端根据当前用户账号或手机号查询设备管理平台。

响应示例：

```json
{
  "devices": [
    {
      "device_id": "ACP-SP2617XXXXX1",
      "serial_num": "SP2617XXXXX1",
      "display_name": "座席设备 1",
      "online": true,
      "enabled": true,
      "caller_phone": "13800138000",
      "reserved": false
    }
  ]
}
```

## 准备呼叫

```http
POST /r1-sip/calls/prepare
Content-Type: application/json
```

请求：

```json
{
  "device_id": "ACP-SP2617XXXXX1",
  "to": "13900139000",
  "source": "web"
}
```

后端动作：

- 校验设备属于当前账号。
- 校验设备可用。
- 原子占用设备。
- 生成 `call_uuid` 和 RTC `channel`。
- 生成设备侧 RTC Token。
- 获取座席侧 MQTT JWT Token。
- 如果是人工座席场景，把 `_source=web` 写入 CALL 消息的 `labels`，使未接通前的运营商提示音可以回传给 Web 端。

响应：

```json
{
  "call_uuid": "uuid",
  "device_id": "ACP-SP2617XXXXX1",
  "appid": "your_app_id",
  "mqtt_ws_url": "wss://example.mqtt/ws",
  "mqtt_client_id": "your_app_id-caller-10001",
  "mqtt_username": "your_app_id-caller-10001",
  "mqtt_token": "jwt",
  "call_topic": "d/your_app_id/ACP-SP2617XXXXX1/call",
  "stop_topic": "d/your_app_id/ACP-SP2617XXXXX1/stop",
  "event_topic": "d/your_app_id/ACP-SP2617XXXXX1/evt/call",
  "channel": "ACP-SP2617XXXXX1-uuid",
  "device_rtc_uid": "10001",
  "device_rtc_token": "rtc-token",
  "to": "13900139000"
}
```

占用失败时返回 409：

```json
{
  "code": "DEVICE_RESERVED",
  "message": "设备正在被使用，请刷新后重试"
}
```

## 获取座席侧 RTC Token

```http
POST /r1-sip/calls/{call_uuid}/rtc-token
Content-Type: application/json
```

请求：

```json
{
  "uid": "20001"
}
```

响应：

```json
{
  "appid": "your_app_id",
  "channel": "ACP-SP2617XXXXX1-uuid",
  "uid": "20001",
  "rtc_token": "rtc-token"
}
```

## 结束通话

```http
POST /r1-sip/calls/{call_uuid}/finish
Content-Type: application/json
```

请求：

```json
{
  "state": "HANGUP",
  "cause": "NORMAL_CLEARING",
  "duration_sec": 62
}
```

后端动作：

- 记录通话结果。
- 释放设备占用。
- 如果状态异常，记录可排查日志。
