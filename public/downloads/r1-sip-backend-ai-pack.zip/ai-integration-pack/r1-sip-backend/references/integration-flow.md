# 后端集成流程

## 总体链路

1. Web 座席端请求当前账号的设备列表。
2. 接入方后端用平台凭证获取设备管理平台 Access Token。
3. 接入方后端调用设备管理平台 Open API 查询设备。
4. Web 座席端选择一台设备并输入被叫号码。
5. 接入方后端对该设备做原子占用。
6. 占用成功后，接入方后端生成本次呼叫的 `call_uuid`、RTC `channel`、设备侧 RTC Token。
7. 接入方后端获取座席侧 MQTT JWT Token，并返回 Web 前端连接 MQTT 所需参数。
8. Web 前端连接 MQTT，订阅设备通话状态 topic。
9. Web 前端向设备 `call` topic 发布 CALL 指令；人工座席场景中，CALL 需要带上 `labels._source=web`。
10. 设备通过已连接手机蓝牙拨打被叫号码，并通过 MQTT 上报 CALL_STATE。
11. 如果运营商在未接通前返回了空号、停机、呼叫等待等提示音，设备会把这部分音频回传给 Web 座席端。
12. 对端接听后，设备加入声网 RTC 频道；人工座席场景下，Web 前端通常需要更早加入同一 RTC 频道，以便接收未接通前提示音。
13. 通话结束、失败或超时后，Web 前端上报结束状态。
14. 接入方后端记录通话结果并释放设备占用。

## 设备占用原则

设备占用必须在后端完成。推荐占用键：

```text
r1sip:device-reservation:{device_id}
```

推荐占用值：

```json
{
  "call_uuid": "uuid",
  "agent_user_id": "current-user-id",
  "device_id": "ACP-SP2617XXXXX1",
  "expires_at": "2026-06-10T10:00:00.000Z"
}
```

占用建议：

- 准备呼叫阶段：短 TTL，例如 10-30 秒。
- 呼叫发起成功后：延长到最大通话保护时长，例如 10-30 分钟。
- 收到结束状态、失败状态、超时任务触发时释放。

## 后端聚合接口建议

不要让 Web 前端分别拼接所有平台细节。建议后端提供聚合接口：

- `GET /r1-sip/devices`：返回当前账号可用设备。
- `POST /r1-sip/calls/prepare`：占用设备并返回 MQTT/RTC 所需参数。
- `POST /r1-sip/calls/{call_uuid}/rtc-token`：返回座席侧 RTC Token。
- `POST /r1-sip/calls/{call_uuid}/finish`：记录结束状态并释放设备。
