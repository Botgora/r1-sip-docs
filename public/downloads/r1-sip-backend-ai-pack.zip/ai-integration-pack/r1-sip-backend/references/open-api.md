# 设备管理平台 Open API 摘要

设备管理平台 Open API 由接入方后端调用，Web 前端不直接访问。

## 平台 URL

设备管理平台 URL 不是声网公共 RTC 或 MQTT 地址。它是客户所在环境的设备管理平台部署地址，请联系技术支持获取。

建议后端配置：

```text
R1SIP_PLATFORM_BASE_URL=https://example-platform
R1SIP_PLATFORM_APP_ID=your_app_id
R1SIP_PLATFORM_APP_SECRET=your_app_secret
```

## 获取 Access Token

```http
POST /api/open/auth/token
Content-Type: application/json
```

请求：

```json
{
  "app_id": "your_app_id",
  "app_secret": "your_app_secret"
}
```

响应字段通常包含：

```json
{
  "access_token": "token",
  "expires_in": 7200
}
```

后端应缓存 `access_token`，并在过期前刷新。

## 查询设备列表

```http
GET /api/open/devices?phone={phone}
Authorization: Bearer {access_token}
```

后端应根据当前登录用户映射到平台查询参数，例如用户手机号、账号 ID 或业务系统中保存的平台账号。

返回设备后，建议后端过滤：

- 是否属于当前账号。
- 是否启用。
- 是否在线。
- 主叫号码是否可用。
- 是否已被当前后端占用。

