# MQTT 协议摘要

MQTT 只承载呼叫信令和状态，不承载语音。语音通过声网 RTC 传输。人工座席场景下，如果 CALL 中传入 `labels._source=web`，未接通前的运营商提示音也会回传给 Web 座席端。

## Web 座席端连接参数

| 参数 | 说明 |
| --- | --- |
| MQTT WebSocket URL | 后端配置后返回给前端 |
| Client ID | `{appid}-caller-{uid}` |
| Username | 通常与 Client ID 一致 |
| Password | MQTT JWT Token |

## Topic

| 方向 | Topic | 说明 |
| --- | --- | --- |
| Web -> 设备 | `d/{appid}/{device_id}/call` | 下发 CALL |
| Web -> 设备 | `d/{appid}/{device_id}/stop` | 下发 STOP |
| 设备 -> Web | `d/{appid}/{device_id}/evt/call` | 上报 CALL_STATE |
| Broker -> Web | `d/{appid}/{device_id}/evt/presence` | 可选，设备在线/离线系统事件 |

## CALL

```json
{
  "event_type": "call",
  "appid": "your_app_id",
  "device_id": "ACP-SP2617XXXXX1",
  "channel": "ACP-SP2617XXXXX1-uuid",
  "uid": "10001",
  "token": "device_rtc_token",
  "call_uuid": "uuid",
  "to": "13900139000",
  "labels": {
    "_direction": "outbound",
    "_source": "web",
    "_from_number": "ACP-SP2617XXXXX1",
    "_to_number": "13900139000"
  }
}
```

`labels._source=web` 的作用：

- 表示当前呼叫来源于 Web 人工座席。
- 允许未接通前的运营商提示音回传给 Web 端。
- 便于销售在空号、停机、忙线、呼叫等待等场景下及时标注号码状态。

## STOP

```json
{
  "appid": "your_app_id"
}
```

## CALL_STATE

```json
{
  "event_type": "call_state",
  "timestamp": "2026-06-10T10:00:00.000Z",
  "appid": "your_app_id",
  "device_id": "ACP-SP2617XXXXX1",
  "channel": "ACP-SP2617XXXXX1-uuid",
  "state": "ANSWERED",
  "call_uuid": "uuid",
  "cause": "NORMAL_CLEARING",
  "duration_sec": 62
}
```

常见状态：

| state | 说明 |
| --- | --- |
| CALLING | 设备开始拨号 |
| RINGING | 对端振铃或未接通前提示阶段 |
| ANSWERED | 对端接听 |
| HANGUP | 通话结束 |
| ERROR | 呼叫失败 |

常见原因码：

| cause | 说明 |
| --- | --- |
| NORMAL_CLEARING | 正常结束 |
| NO_ANSWER | 对端未接 |
| BUSY | 对端忙 |
| HFP_NOT_CONNECT | 手机蓝牙未连接 |
| HFP_NO_SIM | 手机未插 SIM 卡 |
| RTC_JOIN_FAILED | RTC 加入失败 |

注意：如果设备协议中的真实字段仍使用 `HFP_NOT_CONNECT`、`HFP_NO_SIM`，文档和代码应保留真实字段名，但面向用户的提示文案写“手机蓝牙未连接”或“手机未插 SIM 卡”。
