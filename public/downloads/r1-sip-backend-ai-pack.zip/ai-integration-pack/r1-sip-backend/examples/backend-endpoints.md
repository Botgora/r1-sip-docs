# 后端接口设计示例

本文件只提供接口形态，不绑定具体语言或框架。

## 环境变量

```text
R1SIP_PLATFORM_BASE_URL=
R1SIP_PLATFORM_APP_ID=
R1SIP_PLATFORM_APP_SECRET=
R1SIP_MQTT_TOKEN_URL=
R1SIP_MQTT_BASIC_AUTH=
R1SIP_MQTT_WS_URL=
R1SIP_AGORA_APP_ID=
R1SIP_AGORA_APP_CERTIFICATE=
R1SIP_DEVICE_RESERVATION_TTL_SECONDS=30
R1SIP_CALL_MAX_SECONDS=1800
```

## 服务模块建议

```text
R1SipPlatformClient
  getAccessToken()
  listDevices(accountPhone)

R1SipTokenService
  getMqttToken(uid, clientId)
  createRtcToken(channel, uid, expiresIn)

R1SipReservationService
  reserveDevice(deviceId, callUuid, userId, ttl)
  extendReservation(deviceId, callUuid, ttl)
  releaseDevice(deviceId, callUuid)

R1SipCallService
  listAvailableDevices(currentUser)
  prepareCall(currentUser, deviceId, to)
  createAgentRtcToken(currentUser, callUuid, uid)
  finishCall(currentUser, callUuid, result)
```

## 错误码建议

| code | HTTP | 说明 |
| --- | --- | --- |
| DEVICE_NOT_FOUND | 404 | 当前账号下找不到该设备 |
| DEVICE_NOT_AVAILABLE | 409 | 设备不可用 |
| DEVICE_RESERVED | 409 | 设备正在被其他座席使用 |
| PLATFORM_TOKEN_FAILED | 502 | 获取设备管理平台 Token 失败 |
| PLATFORM_DEVICE_QUERY_FAILED | 502 | 查询设备失败 |
| MQTT_TOKEN_FAILED | 502 | 获取 MQTT Token 失败 |
| RTC_TOKEN_FAILED | 500 | 生成 RTC Token 失败 |
| CALL_NOT_FOUND | 404 | 找不到通话会话 |

